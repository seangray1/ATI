({

    // afterRender : function(component, helper) {
    //     this.superAfterRender(); 
    //     var targetEl = component.find("mainapp").getElement();
    //     targetEl.addEventListener("touchmove", function(e) {
    //          e.stopPropagation();
    //      }, false); 
    //  }

})